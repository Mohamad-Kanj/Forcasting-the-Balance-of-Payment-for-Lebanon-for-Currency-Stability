library(fpp2)
library(tseries)
library(ggplot2)
library(forecast)


data = read.csv("/Users/ayazeini/Desktop/infos/AUB/Courses/Spring/Electives/Forecasting/DataFuturists.csv")

# renamed the first column as Date
colnames(data)[1] <- "Date"

# Creating the time series, used frequency = 1 because with 365 as frequency
# R wasn't able to plot the time series.
myts <- ts(data$x, frequency = 365)

# 1) Data visualization and interpretation of the key observations.
# Plot the data
autoplot(myts)
ggseasonplot(myts)
ggAcf(myts, lag=25)

gglagplot(myts)
train <- myts[1:400]
test <- myts[401:500]

datatrain<-ts(train, frequency = 365)

kpss_test <- ur.kpss(datatrain) %>% summary()
print(kpss_test)

Acf(datatrain, lag=25)
Pacf(datatrain,lag=25)

datatrain %>% ggtsdisplay(main="")

auto.arima(datatrain, seasonal=FALSE, stepwise=FALSE, approximation=FALSE)

Arma1 <- Arima(datatrain, order=c(1,0,1))
print(Arma1)

fit <- accuracy(Arma1)
fit

Arma2 <- Arima(datatrain, order=c(2,0,1))
print(Arma2)

fit <- accuracy(Arma2)
fit

Arma3 <- Arima(datatrain, order=c(0,0,5))
print(Arma3)

fit <- accuracy(Arma3)
fit

Arma4 <- Arima(datatrain, order=c(1,0,5))
print(Arma4)

fit <- accuracy(Arma4)
fit

checkresiduals(Arma3) 

fcast2 = forecast(Arma3, h = 14)
autoplot(fcast2)



# Apply simple exponential smoothing to the training set
fit <- ses(datatrain,h=14)

# Generate forecasts for the testing set
forecast_values <- forecast(fit)

# Print the forecasted values
print(forecast_values)

plot(forecast_values)
accuracy(fit)

ses <-ses(datatrain, h=99)
holt <- holt(datatrain,h=99)
holt_damped<-holt(datatrain, h=99, damped=TRUE)

accuracy(holt)
accuracy(Arma3)
accuracy(best_ets_model)
accuracy(ses)
accuracy(holt_damped)
